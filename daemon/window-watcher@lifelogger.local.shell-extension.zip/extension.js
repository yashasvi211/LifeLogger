import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

const DBUS_INTERFACE = `
<node>
  <interface name="org.gnome.Shell.Extensions.LifeLogger">
    <method name="GetActiveWindow">
      <arg type="s" direction="out" name="appName"/>
      <arg type="s" direction="out" name="title"/>
    </method>
  </interface>
</node>`;

export default class LifeLoggerExtension {
    enable() {
        this._dbusImpl = Gio.DBusExportedObject.wrapJSObject(DBUS_INTERFACE, this);
        this._dbusImpl.export(Gio.DBus.session, '/org/gnome/Shell/Extensions/LifeLogger');
    }

    disable() {
        if (this._dbusImpl) {
            this._dbusImpl.unexport();
            this._dbusImpl = null;
        }
    }

    GetActiveWindow() {
        try {
            let focusWindow = global.display.get_focus_window();
            if (focusWindow) {
                let appName = focusWindow.get_wm_class() || focusWindow.get_wm_class_instance() || "Unknown";
                let title = focusWindow.get_title() || "";
                return [appName, title];
            }
        } catch (e) {
            // ignore
        }
        return ["", ""];
    }
}
